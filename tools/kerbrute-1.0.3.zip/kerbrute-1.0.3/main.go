package main

import (
	"github.com/ropnop/kerbrute/cmd"
	"github.com/ropnop/kerbrute/util"
)

func main() {
	util.PrintBanner()
	cmd.Execute()
}
